//MARK: Repositorios
import UIKit
import PlaygroundSupport
import AVKit
import AVFoundation

//estructura para manejo de un nombre y url para el llenado del table view
struct video {
    let name : String
    let url : String
}
//MARK: Clase maestra para  despliegue de table view
class WWDCMasterViewController:UITableViewController{
    
    //arreglo de almacenamiento de las filas
    let videos = [video(name: "Tom Thum: The orchestra in my mouth", url: "https://archive.org/download/TomThum_2013X/TomThum_2013X.mp4"),
                  video(name: "Michael Anti: Behind the Great Firewall of China", url: "https://archive.org/download/MichaelAnti_2012G/MichaelAnti_2012G.mp4"),
                  video(name: "Hannah Fry: The mathematics of love", url: "https://archive.org/download/HannahFry_2014X/HannahFry_2014X.mp4"),
    video(name: "video 4", url: "https://archive.org/download/AmyCuddy_2012G/AmyCuddy_2012G.mp4")]
    
    let cellID = "cellID"
    
    
    override func viewDidLoad() {
        //cambio de valores del título
        navigationItem.title = "Videos con AVkit"
        navigationController?.navigationBar.prefersLargeTitles = true
       //asigna función de el nombre de las celdas
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: cellID)
        //despliega solo las celdas en el arreglo que contiene nuestros videos
        tableView.tableFooterView = UIView()
    }
// referencia para conocer el número de filas que desplegará el table view
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return videos.count
    }
    //
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Catch de los valores del arreglo videos
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath)
        //obtención del nombre en el arrgelo
        cell.textLabel?.text = videos[indexPath.row].name
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //obtiene dirección del URL proveniente del arreglo
        guard let url = URL(string: videos[indexPath.row].url) else{return}
        //creación del reproductor
        let player = AVPlayer(url: url)
        let controller = AVPlayerViewController()
        controller.player = player
        present(controller,animated: true)
        player.play()
    }
}

//MARK: Equivalente del appdelegate

let audioSession = AVAudioSession.sharedInstance()
do{
    try audioSession.setCategory(.playback, mode: .moviePlayback)
    
}catch{
    print("😱")
}
//llamado de la función maestra
let master = WWDCMasterViewController()
let nav = UINavigationController(rootViewController: master)
PlaygroundPage.current.liveView = nav
